from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


def encrypt(text, shift):
    result = ""

    for char in text:

        if 'A' <= char <= 'Z':
            result += chr(
                (ord(char) - ord('A') + shift) % 26
                + ord('A')
            )

        elif 'a' <= char <= 'z':
            result += chr(
                (ord(char) - ord('a') + shift) % 26
                + ord('a')
            )

        else:
            result += char

    return result


def decrypt(text, shift):
    result = ""

    for char in text:

        if 'A' <= char <= 'Z':
            result += chr(
                (ord(char) - ord('A') - shift) % 26
                + ord('A')
            )

        elif 'a' <= char <= 'z':
            result += chr(
                (ord(char) - ord('a') - shift) % 26
                + ord('a')
            )

        else:
            result += char

    return result


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/encrypt", methods=["POST"])
def encrypt_api():

    data = request.get_json()

    text = data.get("text", "")
    shift = data.get("shift", 0)

    try:
        shift = int(shift)
    except (ValueError, TypeError):
        return jsonify({
            "success": False,
            "error": "Shift must be a number."
        }), 400

    encrypted = encrypt(text, shift)

    return jsonify({
        "success": True,
        "original": text,
        "encrypted": encrypted,
        "shift": shift
    })


@app.route("/api/decrypt", methods=["POST"])
def decrypt_api():

    data = request.get_json()

    text = data.get("text", "")
    shift = data.get("shift", 0)

    try:
        shift = int(shift)
    except (ValueError, TypeError):
        return jsonify({
            "success": False,
            "error": "Shift must be a number."
        }), 400

    decrypted = decrypt(text, shift)

    return jsonify({
        "success": True,
        "encrypted": text,
        "decrypted": decrypted,
        "shift": shift
    })


@app.route("/api/verify", methods=["POST"])
def verify_api():

    data = request.get_json()

    text = data.get("text", "")
    shift = data.get("shift", 0)

    try:
        shift = int(shift)
    except (ValueError, TypeError):
        return jsonify({
            "success": False,
            "error": "Shift must be a number."
        }), 400

    encrypted = encrypt(text, shift)
    decrypted = decrypt(encrypted, shift)

    verified = decrypted == text

    return jsonify({
        "success": True,
        "original": text,
        "encrypted": encrypted,
        "decrypted": decrypted,
        "verified": verified,
        "shift": shift
    })


if __name__ == "__main__":
    app.run(debug=True)