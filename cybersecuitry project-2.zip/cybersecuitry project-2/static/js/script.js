const messageInput = document.getElementById("message");
const shiftInput = document.getElementById("shift");
const resultBox = document.getElementById("result");
const charCount = document.getElementById("charCount");
const shiftDisplay = document.getElementById("shiftDisplay");
const verificationStatus =
    document.getElementById("verificationStatus");


messageInput.addEventListener("input", () => {

    charCount.textContent =
        messageInput.value.length;

});


shiftInput.addEventListener("input", () => {

    let value = Number(shiftInput.value);

    if (value >= 0) {
        shiftDisplay.textContent = "+" + value;
    } else {
        shiftDisplay.textContent = value;
    }

});


async function encryptMessage() {

    const text = messageInput.value;
    const shift = shiftInput.value;

    if (!text.trim()) {

        showResult(
            "Please enter a message first.",
            true
        );

        return;
    }


    try {

        const response = await fetch(
            "/api/encrypt",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    text: text,
                    shift: shift
                })
            }
        );


        const data = await response.json();


        if (!data.success) {

            showResult(data.error, true);

            return;
        }


        showResult(data.encrypted);

    } catch (error) {

        showResult(
            "Unable to connect to the server.",
            true
        );

    }

}


async function decryptMessage() {

    const text = messageInput.value;
    const shift = shiftInput.value;

    if (!text.trim()) {

        showResult(
            "Please enter encrypted text first.",
            true
        );

        return;
    }


    try {

        const response = await fetch(
            "/api/decrypt",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    text: text,
                    shift: shift
                })
            }
        );


        const data = await response.json();


        if (!data.success) {

            showResult(data.error, true);

            return;
        }


        showResult(data.decrypted);

    } catch (error) {

        showResult(
            "Unable to connect to the server.",
            true
        );

    }

}


async function verifyMessage() {

    const text = messageInput.value;
    const shift = shiftInput.value;

    if (!text.trim()) {

        showResult(
            "Please enter a message first.",
            true
        );

        return;
    }


    try {

        const response = await fetch(
            "/api/verify",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    text: text,
                    shift: shift
                })
            }
        );


        const data = await response.json();


        if (!data.success) {

            showResult(data.error, true);

            return;
        }


        resultBox.innerHTML = `
            <div>
                <strong>Original:</strong>
                ${escapeHtml(data.original)}
            </div>

            <div style="margin-top:10px">
                <strong>Encrypted:</strong>
                ${escapeHtml(data.encrypted)}
            </div>

            <div style="margin-top:10px">
                <strong>Decrypted:</strong>
                ${escapeHtml(data.decrypted)}
            </div>
        `;


        if (data.verified) {

            verificationStatus.textContent =
                "✓ VERIFIED";

        } else {

            verificationStatus.textContent =
                "✗ FAILED";

        }

    } catch (error) {

        showResult(
            "Unable to connect to the server.",
            true
        );

    }

}


function showResult(message, error = false) {

    resultBox.innerHTML =
        `<span>${escapeHtml(message)}</span>`;

}


function escapeHtml(text) {

    const div = document.createElement("div");

    div.textContent = text;

    return div.innerHTML;

}


async function copyResult() {

    const text =
        resultBox.innerText;

    if (!text.trim()) {
        return;
    }

    try {

        await navigator.clipboard.writeText(text);

        const original =
            document.querySelector(".copy-btn").textContent;

        document.querySelector(".copy-btn").textContent =
            "COPIED ✓";

        setTimeout(() => {

            document.querySelector(".copy-btn").textContent =
                original;

        }, 1500);

    } catch (error) {

        alert("Could not copy result.");

    }

}