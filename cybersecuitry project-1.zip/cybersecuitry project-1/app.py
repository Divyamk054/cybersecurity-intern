from flask import Flask, render_template, request, jsonify

import sys
import os

sys.path.append(
    os.path.join(
        os.path.dirname(__file__),
        "analyzer"
    )
)

from password_analyzer import analyze_password
from pattern_detector import is_common_password


app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    password = data.get("password", "")

    result = analyze_password(password)

    if is_common_password(password):
        result["issues"].append(
            "This is a commonly used password"
        )
        result["strength"] = "Weak"

    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)