COMMON_PASSWORDS = [
    "password",
    "password123",
    "123456",
    "12345678",
    "qwerty",
    "admin",
    "welcome",
    "abc123",
    "letmein",
    "india123"
]


def is_common_password(password):

    return password.lower() in COMMON_PASSWORDS