import math


def has_repeated_characters(password):

    for i in range(len(password) - 2):

        if (
            password[i] ==
            password[i + 1] ==
            password[i + 2]
        ):
            return True

    return False


def has_sequence(password):

    password = password.lower()

    sequences = [
        "0123456789",
        "abcdefghijklmnopqrstuvwxyz"
    ]

    for sequence in sequences:

        for i in range(len(sequence) - 2):

            part = sequence[i:i + 3]

            if part in password:
                return True

    return False


def calculate_entropy(password):

    charset_size = 0

    if any(char.islower() for char in password):
        charset_size += 26

    if any(char.isupper() for char in password):
        charset_size += 26

    if any(char.isdigit() for char in password):
        charset_size += 10

    if any(not char.isalnum() for char in password):
        charset_size += 32

    if charset_size == 0:
        return 0

    entropy = len(password) * math.log2(charset_size)

    return round(entropy, 2)


def analyze_password(password):

    score = 0
    issues = []
    suggestions = []

    if len(password) >= 8:
        score += 1
    else:
        issues.append("Password is too short")
        suggestions.append("Use at least 8 characters")

    if any(char.isupper() for char in password):
        score += 1
    else:
        suggestions.append("Add uppercase letters")

    if any(char.islower() for char in password):
        score += 1
    else:
        suggestions.append("Add lowercase letters")

    if any(char.isdigit() for char in password):
        score += 1
    else:
        suggestions.append("Add numbers")

    if any(not char.isalnum() for char in password):
        score += 1
    else:
        suggestions.append("Add special characters")

    if has_repeated_characters(password):
        score -= 1
        issues.append("Repeated characters detected")

    if has_sequence(password):
        score -= 1
        issues.append("Sequential pattern detected")

    entropy = calculate_entropy(password)

    if score <= 2:
        strength = "Weak"

    elif score <= 4:
        strength = "Medium"

    else:
        strength = "Strong"

    return {
        "strength": strength,
        "score": score,
        "entropy": entropy,
        "issues": issues,
        "suggestions": suggestions
    }