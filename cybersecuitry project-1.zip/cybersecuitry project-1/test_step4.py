import sys
import os

sys.path.append(
    os.path.join(
        os.path.dirname(__file__),
        "analyzer"
    )
)

from pattern_detector import is_common_password
from password_analyzer import has_repeated_characters, has_sequence, calculate_entropy


password = input("Enter password: ")

print("Common Password:", is_common_password(password))
print("Repeated Characters:", has_repeated_characters(password))
print("Sequence:", has_sequence(password))
print("Entropy:", calculate_entropy(password), "bits")