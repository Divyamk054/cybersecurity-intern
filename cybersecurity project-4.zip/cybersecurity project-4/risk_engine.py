def calculate_risk(checks):

    risk_points = 0

    for check in checks:

        severity = check["severity"]

        if severity == "HIGH":
            risk_points += 20

        elif severity == "MEDIUM":
            risk_points += 10

        elif severity == "LOW":
            if check["status"] != "PASS":
                risk_points += 5

    # Keep score between 0 and 100
    security_score = max(0, 100 - risk_points)

    if security_score >= 80:
        level = "GOOD"

    elif security_score >= 60:
        level = "MODERATE"

    elif security_score >= 40:
        level = "HIGH RISK"

    else:
        level = "CRITICAL"

    return {
        "risk_points": risk_points,
        "security_score": security_score,
        "security_level": level
    }