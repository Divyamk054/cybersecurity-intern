import subprocess
import platform
import socket
from datetime import datetime


def run_powershell(command):
    """Run a PowerShell command safely and return its output."""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", command],
            capture_output=True,
            text=True,
            timeout=15
        )

        if result.returncode == 0:
            return result.stdout.strip()

        return ""

    except Exception as e:
        return f"ERROR: {e}"


def get_system_info():
    return {
        "computer_name": socket.gethostname(),
        "username": subprocess.getoutput("whoami"),
        "operating_system": platform.system(),
        "os_version": platform.version(),
        "audit_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }


def check_password_policy():
    output = run_powershell(
        "Get-LocalUser | Select-Object Name,Enabled,PasswordRequired | Format-Table -HideTableHeaders"
    )

    if not output:
        return {
            "name": "Password Policy",
            "status": "REVIEW",
            "severity": "MEDIUM",
            "details": "Unable to retrieve local password information."
        }

    weak_accounts = []

    for line in output.splitlines():
        parts = line.split()

        if len(parts) >= 3:
            username = parts[0]
            enabled = parts[1]
            password_required = parts[2]

            if enabled.lower() == "true" and password_required.lower() == "false":
                weak_accounts.append(username)

    if weak_accounts:
        return {
            "name": "Password Policy",
            "status": "FAIL",
            "severity": "HIGH",
            "details": f"Password not required for: {', '.join(weak_accounts)}"
        }

    return {
        "name": "Password Policy",
        "status": "PASS",
        "severity": "LOW",
        "details": "Enabled local accounts require passwords."
    }


def check_guest_account():
    output = run_powershell(
        "Get-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue | "
        "Select-Object -ExpandProperty Enabled"
    )

    if output.lower() == "true":
        return {
            "name": "Guest Account",
            "status": "FAIL",
            "severity": "HIGH",
            "details": "Guest account is enabled."
        }

    return {
        "name": "Guest Account",
        "status": "PASS",
        "severity": "LOW",
        "details": "Guest account is disabled or unavailable."
    }


def check_firewall():
    output = run_powershell(
        "Get-NetFirewallProfile | Select-Object Name,Enabled | ConvertTo-Csv -NoTypeInformation"
    )

    if not output:
        return {
            "name": "Windows Firewall",
            "status": "REVIEW",
            "severity": "MEDIUM",
            "details": "Unable to check firewall status."
        }

    disabled_profiles = []

    for line in output.splitlines()[1:]:
        parts = line.replace('"', "").split(",")

        if len(parts) >= 2:
            profile = parts[0]
            enabled = parts[1]

            if enabled.lower() == "false":
                disabled_profiles.append(profile)

    if disabled_profiles:
        return {
            "name": "Windows Firewall",
            "status": "FAIL",
            "severity": "HIGH",
            "details": "Firewall disabled for: " +
                       ", ".join(disabled_profiles)
        }

    return {
        "name": "Windows Firewall",
        "status": "PASS",
        "severity": "LOW",
        "details": "Firewall is enabled for all profiles."
    }


def check_admin_accounts():
    output = run_powershell(
        "Get-LocalGroupMember -Group 'Administrators' "
        "-ErrorAction SilentlyContinue | "
        "Select-Object -ExpandProperty Name"
    )

    if not output:
        return {
            "name": "Administrator Accounts",
            "status": "REVIEW",
            "severity": "MEDIUM",
            "details": "Unable to inspect administrator accounts."
        }

    accounts = output.splitlines()

    return {
        "name": "Administrator Accounts",
        "status": "REVIEW",
        "severity": "MEDIUM",
        "details": "Administrator group members: " +
                   ", ".join(accounts)
    }


def check_windows_update_service():
    output = run_powershell(
        "Get-Service wuauserv | Select-Object -ExpandProperty Status"
    )

    if output.lower() == "running":
        return {
            "name": "Windows Update Service",
            "status": "PASS",
            "severity": "LOW",
            "details": "Windows Update service is running."
        }

    return {
        "name": "Windows Update Service",
        "status": "FAIL",
        "severity": "HIGH",
        "details": "Windows Update service is not running."
    }


def check_screen_lock():
    output = run_powershell(
        "Get-ItemProperty "
        "'HKCU:\\Control Panel\\Desktop' "
        "-Name ScreenSaveActive -ErrorAction SilentlyContinue"
    )

    if "1" in output:
        return {
            "name": "Screen Lock",
            "status": "PASS",
            "severity": "LOW",
            "details": "Screen saver/lock configuration is enabled."
        }

    return {
        "name": "Screen Lock",
        "status": "REVIEW",
        "severity": "MEDIUM",
        "details": "Automatic screen locking should be verified."
    }


def user_practices_check():
    return {
        "name": "Unsafe User Practices",
        "status": "REVIEW",
        "severity": "MEDIUM",
        "details": (
            "Verify strong passwords, MFA usage, "
            "safe browsing, email awareness, "
            "USB safety and workstation locking."
        )
    }


def run_all_checks():

    print("[SYS_INIT] Establishing baseline... [OK]")
    print("[AUTH] Loading Blue Team protocols... [OK]")

    checks = []

    print("[AUTH] Checking password policy...")
    checks.append(check_password_policy())

    print("[AUTH] Checking Guest account...")
    checks.append(check_guest_account())

    print("[NET] Checking Windows Firewall...")
    checks.append(check_firewall())

    print("[AUTH] Checking administrator accounts...")
    checks.append(check_admin_accounts())

    print("[PATCH] Checking Windows Update service...")
    checks.append(check_windows_update_service())

    print("[USER] Checking screen lock...")
    checks.append(check_screen_lock())

    print("[USER] Checking unsafe user practices...")
    checks.append(user_practices_check())

    print("[RISK] Security checks completed... [OK]")

    return checks