import tkinter as tk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText

from scanner import get_system_info, run_all_checks
from risk_engine import calculate_risk
from report_generator import generate_report


class SecurityAuditApp:

    def __init__(self, root):

        self.root = root

        self.root.title(
            "Project 4 - System Vulnerability Checklist"
        )

        self.root.geometry("1000x700")

        self.root.configure(bg="#0b1220")

        self.system_info = {}
        self.checks = []
        self.risk = {}

        self.create_header()
        self.create_system_section()
        self.create_output_section()
        self.create_buttons()

    # ---------------- HEADER ----------------

    def create_header(self):

        header = tk.Frame(
            self.root,
            bg="#111c30",
            height=100
        )

        header.pack(fill="x")

        title = tk.Label(
            header,
            text="SYSTEM VULNERABILITY CHECKLIST",
            font=("Arial", 24, "bold"),
            fg="#00e5ff",
            bg="#111c30"
        )

        title.pack(pady=(20, 2))

        subtitle = tk.Label(
            header,
            text="AUDITED SYSTEMS • BLUE TEAM DEFENSE",
            font=("Arial", 11),
            fg="#9aa8bd",
            bg="#111c30"
        )

        subtitle.pack()

    # ---------------- SYSTEM INFO ----------------

    def create_system_section(self):

        frame = tk.LabelFrame(
            self.root,
            text=" SYSTEM INFORMATION ",
            font=("Arial", 11, "bold"),
            fg="#00e5ff",
            bg="#0b1220",
            bd=1
        )

        frame.pack(
            fill="x",
            padx=20,
            pady=15
        )

        self.system_label = tk.Label(
            frame,
            text="Click RUN SECURITY SCAN to collect system information.",
            font=("Consolas", 11),
            fg="white",
            bg="#0b1220",
            justify="left"
        )

        self.system_label.pack(
            anchor="w",
            padx=15,
            pady=12
        )

    # ---------------- OUTPUT ----------------

    def create_output_section(self):

        frame = tk.LabelFrame(
            self.root,
            text=" SECURITY AUDIT ",
            font=("Arial", 11, "bold"),
            fg="#00e5ff",
            bg="#0b1220"
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=20
        )

        self.output = ScrolledText(
            frame,
            bg="#050a12",
            fg="#00ff9d",
            insertbackground="white",
            font=("Consolas", 10),
            height=20
        )

        self.output.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

    # ---------------- BUTTONS ----------------

    def create_buttons(self):

        frame = tk.Frame(
            self.root,
            bg="#0b1220"
        )

        frame.pack(
            fill="x",
            pady=15
        )

        scan_button = tk.Button(
            frame,
            text="RUN SECURITY SCAN",
            command=self.run_scan,
            font=("Arial", 11, "bold"),
            bg="#00a8cc",
            fg="white",
            padx=20,
            pady=10
        )

        scan_button.pack(
            side="left",
            padx=20
        )

        report_button = tk.Button(
            frame,
            text="GENERATE REPORT",
            command=self.generate_report,
            font=("Arial", 11, "bold"),
            bg="#673ab7",
            fg="white",
            padx=20,
            pady=10
        )

        report_button.pack(
            side="left",
            padx=10
        )

        clear_button = tk.Button(
            frame,
            text="CLEAR",
            command=self.clear_output,
            font=("Arial", 11),
            bg="#263449",
            fg="white",
            padx=20,
            pady=10
        )

        clear_button.pack(
            side="right",
            padx=20
        )

    # ---------------- SCAN ----------------

    def run_scan(self):

        self.output.delete(
            "1.0",
            tk.END
        )

        self.output.insert(
            tk.END,
            "[SYS_INIT] Establishing baseline... [OK]\n"
        )

        self.output.insert(
            tk.END,
            "[AUTH] Loading Blue Team protocols... [OK]\n\n"
        )

        self.root.update()

        self.system_info = get_system_info()

        self.system_label.config(
            text=(
                f"Computer Name : {self.system_info['computer_name']}\n"
                f"Username      : {self.system_info['username']}\n"
                f"Operating OS  : {self.system_info['operating_system']}\n"
                f"OS Version    : {self.system_info['os_version']}\n"
                f"Audit Time    : {self.system_info['audit_time']}"
            )
        )

        self.checks = run_all_checks()

        for check in self.checks:

            if check["status"] == "PASS":
                symbol = "✓"

            elif check["severity"] == "HIGH":
                symbol = "✗"

            else:
                symbol = "⚠"

            self.output.insert(
                tk.END,
                f"{symbol} {check['name']}\n"
            )

            self.output.insert(
                tk.END,
                f"   Status   : {check['status']}\n"
            )

            self.output.insert(
                tk.END,
                f"   Severity : {check['severity']}\n"
            )

            self.output.insert(
                tk.END,
                f"   Details  : {check['details']}\n\n"
            )

        self.risk = calculate_risk(
            self.checks
        )

        self.output.insert(
            tk.END,
            "\n"
            + "=" * 55
            + "\n"
        )

        self.output.insert(
            tk.END,
            "RISK ASSESSMENT\n"
        )

        self.output.insert(
            tk.END,
            "=" * 55
            + "\n"
        )

        self.output.insert(
            tk.END,
            f"Risk Points    : {self.risk['risk_points']}\n"
        )

        self.output.insert(
            tk.END,
            f"Security Score : {self.risk['security_score']}/100\n"
        )

        self.output.insert(
            tk.END,
            f"Risk Level     : {self.risk['security_level']}\n"
        )

        self.output.insert(
            tk.END,
            "\n[COMPLETE] Security audit finished.\n"
        )

    # ---------------- REPORT ----------------

    def generate_report(self):

        if not self.checks:

            messagebox.showwarning(
                "No Scan",
                "Please run the security scan first."
            )

            return

        filename = generate_report(
            self.system_info,
            self.checks,
            self.risk
        )

        messagebox.showinfo(
            "Report Generated",
            f"Security report created successfully:\n\n{filename}"
        )

    # ---------------- CLEAR ----------------

    def clear_output(self):

        self.output.delete(
            "1.0",
            tk.END
        )


# ---------------- START APPLICATION ----------------

if __name__ == "__main__":

    root = tk.Tk()

    app = SecurityAuditApp(root)

    root.mainloop()