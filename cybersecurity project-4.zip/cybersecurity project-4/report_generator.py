import os
from datetime import datetime


def generate_report(system_info, checks, risk):

    os.makedirs("reports", exist_ok=True)

    filename = (
        "reports/security_report_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
        + ".txt"
    )

    with open(filename, "w", encoding="utf-8") as file:

        file.write("=" * 60 + "\n")
        file.write("       SYSTEM VULNERABILITY ASSESSMENT REPORT\n")
        file.write("=" * 60 + "\n\n")

        file.write("PROJECT  : Project 4 - System Vulnerability Checklist\n")
        file.write("TYPE     : Blue Team Endpoint Security Audit\n\n")

        file.write("SYSTEM INFORMATION\n")
        file.write("-" * 60 + "\n")

        file.write(
            f"Computer Name : {system_info['computer_name']}\n"
        )

        file.write(
            f"Username      : {system_info['username']}\n"
        )

        file.write(
            f"Operating OS  : {system_info['operating_system']}\n"
        )

        file.write(
            f"OS Version    : {system_info['os_version']}\n"
        )

        file.write(
            f"Audit Time    : {system_info['audit_time']}\n\n"
        )

        file.write("SECURITY FINDINGS\n")
        file.write("-" * 60 + "\n")

        for i, check in enumerate(checks, start=1):

            file.write(f"\n{i}. {check['name']}\n")
            file.write(f"   Status   : {check['status']}\n")
            file.write(f"   Severity : {check['severity']}\n")
            file.write(f"   Details  : {check['details']}\n")

        file.write("\n")
        file.write("=" * 60 + "\n")
        file.write("SECURITY SCORE\n")
        file.write("=" * 60 + "\n")

        file.write(
            f"Risk Points    : {risk['risk_points']}\n"
        )

        file.write(
            f"Security Score : {risk['security_score']}/100\n"
        )

        file.write(
            f"Risk Level     : {risk['security_level']}\n"
        )

        file.write("\nRECOMMENDATIONS\n")
        file.write("-" * 60 + "\n")

        file.write(
            "1. Use strong and unique passwords.\n"
        )

        file.write(
            "2. Enable multi-factor authentication where available.\n"
        )

        file.write(
            "3. Keep Windows and installed software updated.\n"
        )

        file.write(
            "4. Keep Windows Firewall enabled.\n"
        )

        file.write(
            "5. Disable unused accounts such as Guest.\n"
        )

        file.write(
            "6. Remove unnecessary administrator privileges.\n"
        )

        file.write(
            "7. Lock the workstation when unattended.\n"
        )

        file.write(
            "8. Avoid suspicious links and email attachments.\n"
        )

        file.write(
            "9. Do not share passwords or credentials.\n"
        )

        file.write(
            "10. Avoid unknown USB devices.\n"
        )

        file.write("\n")
        file.write("=" * 60 + "\n")
        file.write("END OF REPORT\n")
        file.write("=" * 60 + "\n")

    return filename