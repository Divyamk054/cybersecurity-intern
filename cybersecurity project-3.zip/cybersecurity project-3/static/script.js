function analyzeMessage() {

    const sender =
        document.getElementById("sender").value.trim();

    const subject =
        document.getElementById("subject").value.trim();

    const message =
        document.getElementById("message").value.trim();


    if (!message) {

        alert("Please enter a sample message.");

        return;
    }


    const text =
        (sender + " " + subject + " " + message)
        .toLowerCase();


    let score = 0;

    let redFlags = [];


    /*
       1. URGENCY
    */

    const urgencyWords = [
        "urgent",
        "immediately",
        "act now",
        "within 24 hours",
        "expires today",
        "final warning",
        "as soon as possible"
    ];


    urgencyWords.forEach(word => {

        if (text.includes(word)) {

            score += 12;

            redFlags.push(
                "Urgent or pressure-based language"
            );

        }

    });


    /*
       2. CREDENTIAL REQUEST
    */

    const credentialWords = [
        "password",
        "login",
        "username",
        "verify your account",
        "verification code",
        "otp",
        "credentials"
    ];


    credentialWords.forEach(word => {

        if (text.includes(word)) {

            score += 15;

            redFlags.push(
                "Request involving credentials or account verification"
            );

        }

    });


    /*
       3. FINANCIAL REQUEST
    */

    const financialWords = [
        "payment",
        "invoice",
        "bank",
        "credit card",
        "debit card",
        "refund",
        "money",
        "transfer"
    ];


    financialWords.forEach(word => {

        if (text.includes(word)) {

            score += 12;

            redFlags.push(
                "Financial or payment-related request"
            );

        }

    });


    /*
       4. THREATS
    */

    const threatWords = [
        "account will be closed",
        "account suspended",
        "legal action",
        "penalty",
        "lose access",
        "security alert"
    ];


    threatWords.forEach(word => {

        if (text.includes(word)) {

            score += 12;

            redFlags.push(
                "Threatening or fear-based language"
            );

        }

    });


    /*
       5. LINKS
    */

    const urlPattern =
        /(https?:\/\/[^\s]+)/gi;

    const urls =
        message.match(urlPattern);


    if (urls) {

        score += 15;

        redFlags.push(
            "Message contains a clickable URL"
        );


        urls.forEach(url => {

            try {

                const cleanUrl =
                    url.replace(/[.,!?)]$/, "");

                const parsed =
                    new URL(cleanUrl);


                /*
                   HTTP instead of HTTPS
                */

                if (parsed.protocol === "http:") {

                    score += 10;

                    redFlags.push(
                        "URL uses HTTP instead of HTTPS"
                    );

                }


                /*
                   IP address as hostname
                */

                if (
                    /^\d{1,3}(\.\d{1,3}){3}$/
                    .test(parsed.hostname)
                ) {

                    score += 20;

                    redFlags.push(
                        "URL uses an IP address instead of a normal domain"
                    );

                }


                /*
                   @ symbol
                */

                if (cleanUrl.includes("@")) {

                    score += 15;

                    redFlags.push(
                        "URL contains an unusual @ symbol"
                    );

                }


                /*
                   Suspicious URL keywords
                */

                const suspiciousDomains = [
                    "login",
                    "verify",
                    "secure",
                    "account",
                    "update"
                ];


                suspiciousDomains.forEach(word => {

                    if (
                        parsed.hostname.includes(word)
                    ) {

                        score += 5;

                        redFlags.push(
                            "URL contains a sensitive-looking keyword: " +
                            word
                        );

                    }

                });

            }

            catch (error) {

                score += 10;

                redFlags.push(
                    "URL could not be safely parsed"
                );

            }

        });

    }


    /*
       6. ATTACHMENT
    */

    const attachmentWords = [
        "attachment",
        ".exe",
        ".zip",
        ".docm",
        ".xlsm",
        ".js file"
    ];


    attachmentWords.forEach(word => {

        if (text.includes(word)) {

            score += 10;

            redFlags.push(
                "Potentially risky attachment reference"
            );

        }

    });


    /*
       7. SENDER CHECK
    */

    if (sender) {

        if (
            sender.includes("gmail.com") ||
            sender.includes("yahoo.com") ||
            sender.includes("outlook.com")
        ) {

            redFlags.push(
                "Sender uses a generic email provider"
            );

        }

    }


    /*
       LIMIT SCORE
    */

    score = Math.min(score, 100);


    /*
       REMOVE DUPLICATE FLAGS
    */

    redFlags =
        [...new Set(redFlags)];


    /*
       DETERMINE RISK
    */

    let risk;

    let explanation;

    let recommendation;


    if (score >= 60) {

        risk = "🔴 HIGH RISK";

        explanation =
            "The message contains multiple indicators commonly associated with phishing. Treat the message as potentially unsafe and avoid interacting with links, attachments, or requests for sensitive information.";

        recommendation =
            "PAUSE → VERIFY → REPORT. Do not click links or provide credentials. Verify the request through a trusted independent channel and report the message to the appropriate security team.";

    }

    else if (score >= 30) {

        risk = "🟡 SUSPICIOUS";

        explanation =
            "The message contains some suspicious characteristics. The available indicators are not enough to establish that it is malicious, so independent verification is recommended.";

        recommendation =
            "PAUSE → VERIFY. Do not act on the request until it has been independently confirmed.";

    }

    else {

        risk = "🟢 LOW RISK";

        explanation =
            "The automated checks did not identify many common phishing indicators. This does not guarantee that the message is safe.";

        recommendation =
            "Continue to use normal security practices. If anything about the message feels unusual, verify it through a trusted channel.";

    }


    /*
       DISPLAY RESULT
    */

    document.getElementById("riskLevel")
        .innerHTML = risk;


    document.getElementById("score")
        .innerHTML =
        "<strong>Risk Score:</strong> "
        + score
        + "/100";


    let flagHTML =
        "<h3>🚩 Red Flags Detected</h3>";


    if (redFlags.length === 0) {

        flagHTML +=
            "<p>No obvious red flags were detected by this basic rule-based analysis.</p>";

    }

    else {

        flagHTML += "<ul>";

        redFlags.forEach(flag => {

            flagHTML +=
                "<li>⚠️ " + flag + "</li>";

        });

        flagHTML += "</ul>";

    }


    document.getElementById("redFlags")
        .innerHTML = flagHTML;


    document.getElementById("explanation")
        .innerHTML =
        "<h3>Why?</h3><p>"
        + explanation
        + "</p>";


    document.getElementById("recommendation")
        .innerHTML =
        "<h3>Recommended Action</h3><p>"
        + recommendation
        + "</p>";

}


/*
   SAMPLE MESSAGE
*/

function loadSample() {

    document.getElementById("sender").value =
        "security-alert@example.net";


    document.getElementById("subject").value =
        "URGENT: Verify Your Account";


    document.getElementById("message").value =
`URGENT: Your account will be suspended within 24 hours.

Please verify your account immediately.

Click the following link:
https://example.net/verify-account

Do not ignore this security alert.`;

}