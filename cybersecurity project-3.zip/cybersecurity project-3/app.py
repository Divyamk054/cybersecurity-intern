from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():

    data = request.get_json()

    sender = data.get("sender", "")
    subject = data.get("subject", "")
    message = data.get("message", "")

    text = (
        sender + " " +
        subject + " " +
        message
    ).lower()

    score = 0
    red_flags = []


    # Urgency
    urgency_words = [
        "urgent",
        "immediately",
        "act now",
        "within 24 hours",
        "final warning",
        "expires today"
    ]

    for word in urgency_words:
        if word in text:
            score += 12
            red_flags.append(
                "Urgent or pressure-based language"
            )


    # Credential requests
    credential_words = [
        "password",
        "username",
        "login",
        "otp",
        "verification code",
        "verify your account",
        "credentials"
    ]

    for word in credential_words:
        if word in text:
            score += 15
            red_flags.append(
                "Request involving credentials or account verification"
            )


    # Financial requests
    financial_words = [
        "payment",
        "bank",
        "credit card",
        "debit card",
        "refund",
        "invoice",
        "money transfer"
    ]

    for word in financial_words:
        if word in text:
            score += 12
            red_flags.append(
                "Financial or payment-related request"
            )


    # Threats
    threat_words = [
        "account will be closed",
        "account suspended",
        "legal action",
        "penalty",
        "lose access"
    ]

    for word in threat_words:
        if word in text:
            score += 12
            red_flags.append(
                "Threatening or fear-based language"
            )


    # URL
    if "http://" in text or "https://" in text:

        score += 15

        red_flags.append(
            "Message contains a URL"
        )


    # HTTP
    if "http://" in text:

        score += 10

        red_flags.append(
            "URL uses HTTP instead of HTTPS"
        )


    # Attachment
    attachment_words = [
        ".exe",
        ".zip",
        ".docm",
        ".xlsm",
        "attachment"
    ]

    for word in attachment_words:

        if word in text:

            score += 10

            red_flags.append(
                "Potentially risky attachment reference"
            )


    # Limit score
    score = min(score, 100)


    # Remove duplicates
    red_flags = list(dict.fromkeys(red_flags))


    # Classification
    if score >= 60:

        risk = "HIGH RISK"

        explanation = (
            "The message contains multiple indicators "
            "commonly associated with phishing."
        )

        recommendation = (
            "PAUSE → VERIFY → REPORT. "
            "Do not click links or provide sensitive information."
        )

    elif score >= 30:

        risk = "SUSPICIOUS"

        explanation = (
            "The message contains suspicious characteristics "
            "that should be independently verified."
        )

        recommendation = (
            "PAUSE → VERIFY before taking any action."
        )

    else:

        risk = "LOW RISK"

        explanation = (
            "The automated checks found relatively few "
            "common phishing indicators."
        )

        recommendation = (
            "Continue normal security practices and verify "
            "unexpected requests."
        )


    return jsonify({
        "risk": risk,
        "score": score,
        "red_flags": red_flags,
        "explanation": explanation,
        "recommendation": recommendation
    })


if __name__ == "__main__":
    app.run(debug=True)